#include <iostream>
 
using namespace std;
 
int main() {
    cout<<"THIS IS MY CODE!"<<endl;
    return 0;
}